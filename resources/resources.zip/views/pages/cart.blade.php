@extends('layouts.template')
@section('main')
    <section class="max-w-screen-xl m-auto p-4">

            @livewire('cart-table')

    </section>
@endsection
