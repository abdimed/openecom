<div class="flex flex-col justify-center items-center my-10">

    <span class="text-center text-2xl font-bold">
        {{ session('orderPosted') }}
    </span>
    <img src="{{ asset('build/assets/success.png') }}" alt="success" class="w-48">

</div>
