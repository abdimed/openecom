<button class="rounded-md bg-primary text-white uppercase p-2 text-sm">
    {{ $slot }}
</button>
