<div wire:loading.flex class="absolute w-full h-full bg-white/50 inset-0 cursor-wait z-50">

    <img src="{{ asset('assets/loading.svg') }}" alt="loading..." class="m-auto w-28">

</div>
