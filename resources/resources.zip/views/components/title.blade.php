<h2 class="text-2xl lg:text-3xl font-semibold flex w-full items-center space-x-10 mb-4 lg:my-10">
    {{ $slot }}
    <hr class="h-1 grow bg-gray-200 ml-5">
</h2>
