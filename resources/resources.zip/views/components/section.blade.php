<section id="{{ $id }}" class="max-w-screen-xl mx-auto py-10 px-4 relative z-10">

    {{ $slot }}

</section>
