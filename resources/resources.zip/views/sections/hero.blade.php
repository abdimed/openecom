<div class="flex w-full max-w-[2200px] h-[500px] lg:h-[550px] bg-cover bg-center"
    style="background-image: url('{{ asset('assets/banner1.jpg') }}')">

    <x-section id="hero">

        <div class="lg:w-3/5 backdrop-blur bg-primary/50 lg:py-10 lg:px-4">
            <span class="text-5xl lg:text-7xl text-center font-bold text-white">
                Meilleurs Outils Dans Un Seul Site!

            </span>
        </div>
    </x-section>

</div>
