<div class="grid grid-cols-1 lg:grid-cols-5 max-w-screen-xl m-auto text-white p-4 w-full">
    <div class="col-span-2">
        <img src="{{ asset('assets/logo.png') }}" alt="logo">
        <a href="tel:+21356153196" class="font-semibold mt-5 block">Numéro :<span class="font-normal">0561531963</span>
            </span> </a>
        <a href="tel:+21356153196" class="font-semibold mt-2 block">Numéro :<span class="font-normal">0561531963</span>
            </span> </a>
        <a href="tel:+21356153196" class="font-semibold mt-2 block">Numéro :<span class="font-normal">0561531963</span>
            </span> </a>

        <p class="font-semibold mt-5 block">Adress: <span>oran oran</span></p>

        <a href="mailto:hello@ccbo.com" class="font-semibold mt-5 block">email@email.com </a>
    </div>

    <div>
        <h4>Categories</h4>
    </div>
    <div>
        text
    </div>

    <div>
        text
    </div>

</div>
