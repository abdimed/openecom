<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <title>Facture {{ $order->number }}</title>
</head>

<body>
    {{-- <img src="{{ asset('assets/logo.png') }}" alt="zz"> --}}
    <h1>
        Bon de livraison {{$order->number}}
    </h1>
    <h3>SARL CCBO IMPORTATION MDF / MELAMINE / HIGH GLOSS
        ET ACCESSOIRES DE DRESSING ET CUISINE</h3>

    <p>
        ccbo dar el beida
        <span>
            TEL : 0560-236-871 / 0555-017-182 / 0552-829-656 <br>
            Email : marketing@ccbo-dz.com <br>
            Site : www.ccbo-dz.com <br>
            Adresse : CitË GETAL N°15 DAR EL BEIDA,ORAN
        </span>
    </p>
</body>

</html>
